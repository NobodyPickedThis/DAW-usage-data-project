1. General information 

Title of the dataset: DAW Usage Survey (2023)
Contact information of the data manager: Luca A. Ludovico (luca.ludovico@unimi.it)
Date of data collection: from 2023-12-06 to 2024-07-24
Funding sources or sponsorship that supported the research: no funding


2. Sharing and access information 

Licenses/restrictions: CC0 licence


3. Data and files overview 

List of files: daw_survey.json

The JSON file contains survey responses regarding the use of Digital Audio Workstations (DAWs). Each entry represents an individual respondent and consists of two main sections:

PersonalData (user profiling with no sensitive data):

- "Gender": Gender of the respondent.
- "Age": Age range of the respondent.
- "Country": Country of residence.
- "Instrument": List of instruments the respondent plays.
- "Level": Level of involvement in music (Hobby or Job).
- "Company": Whether the respondent works for a company or is a freelancer.
- "Training": Whether they have received formal training.
- "DAW": Primary DAW they use (see Appendix 1 below).
- "Source": Source of the survey response (anonymized).

UseCases (a list of cases where the respondent has used DAWs):
- "id": Identifier for the use case.
- "OS": Operating system used (Linux, Mac, or Windows).
- "DAW": Specific DAW used (see Appendix 1 below).
- "Start": Year the respondent started using this DAW.
- "End": Year the respondent stopped using this DAW or the latest year they reported using it.
- "Task": List of tasks performed (see Appendix 2 below).
- "Context": List of contexts in which they use the DAW (see Appendix 3 below).
- "Level": Level of expertise for this specific use case (Amateur, Semi-professional, or Professional).


4. Methodological information 

Data have been collected through a web form available at collection or generation (include links or references to publications or other documentation containing experimental design or protocols used) 
Data are presented in a raw, unprocessed format. 

Since JSON is a plain-text format, no proprietary software or instrument-specific information is needed to understand or interpret the data. Any digital text editor can open the dataset. Nevertheless, software capable of JSON formatting is recommended.


---

Appendix 1. DAWs

- Ableton Live (Ableton)
- Acid pro (MAGIX Software GmbH)
- Acoustica Mixcraft (Acoustica)
- Adobe Audition (Adobe)
- Ardour (Ardour Community)
- Audacity (Muse Group)
- AudioMulch (Sonic Fritter Pty Ltd)
- Audiotool (Audiotool)
- Biab (Pro max)
- Bitwig Studio (Bitwig GmbH)
- BTV Solo (BKE Technology)
- Cakewalk (BandLab)
- Caustic (Single Cell Software)
- Cubase (Steinberg)
- Digital Performer (MOTU)
- EnergyXT (XT Software)
- FL Studio (Image-Line Software)
- GarageBand (Apple)
- GoldWave (GoldWave Inc.)
- Mixbus (Harrison Audio Consoles)
- Hindenburg Journalist (Hindenburg Systems)
- Logic Pro (Apple)
- LUNA (Universal Audio)
- Music Maker (MAGIX Software GmbH)
- MainStage (Apple)
- MuLab (MuTools)
- Non DAW Studio (Tux Family)
- n-Track Studio (n-Track Software)
- Nuendo (Steinberg Media Technologies)
- OHM Studio (Steam)
- Podium (Zynewave
- Pro Tools (Avid Technology)
- Pyramix (Merging)
- Reaktor (Native Instruments)
- REAPER (Cockos Incorporated)
- Reason (Reason Studios)
- Renoise (Renoise)
- RX (iZotope)
- Samplitude (MAGIX Software GmbH)
- Sequoia (MAGIX Software GmbH)
- Serato Studio (Serato)
- Sonic Visualizer (Queen Mary University)
- Soundbooth (Adobe)
- SoundBridge (SoundBridge)
- Sound Forge (MAGIX Software GmbH)
- Soundtrap (Spotify)
- SpectraLayers (Steinberg)
- Studio One (PreSonus)
- Tenacity (Tenacity Community)
- Tracktion T7 (Tracktion Software Corporation)
- Tracktor (Native Instruments)
- Waveform (Tracktion Software Corporation)
- WaveLab (Steinberg)
- Other (Not listed here)


Appendix 2. Tasks

- Draft
- Tracking
- Editing
- Sequencing / Programming
- Mixing
- Mastering
- Post-production
- Live performance
- Live sound engineering
- Restoration
- Teaching
- Scientific research/measuring
- Other (Not listed here)


Appendix 3. Contexts

- Acoustic music
- Electroacoustic music
- Electronic music
- Sampling
- Sound art
- Sound design
- Sound foley
- Soundtrack
- Speech recording
- Voice dubbing / Voice-over
- Other (Not listed here)
